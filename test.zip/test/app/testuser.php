<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class testuser extends Model
{
    //
    protected $fillable = ['firstname', 'lastname', 'email','password'];

    protected $table = 'testuser';
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\testuser;


class MainController extends Controller
{
    //
    public function index()
    {
        return view('index');

    }
    public function GetSigninPage(Request $request)
    {
        return view('login');
    }
    public function GetSignupPage(Request $request)
    {
        return view('signup');
    }
    public function postSignupPage(Request $request)
    {
        $this->validate($request, [
            'firstname' => 'required',
            'lastname' => 'required',
            'email' => 'required',
            'password' => 'required|confirmed|min:7|max:255',
        ]);

        // dd($request->all());

        $user = new testuser;
        $user->firstname = $request->firstname;
        $user->lastname = $request->lastname;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->save();

        
        return redirect()->route('index');

    }

    public function postloginPage(Request $request)
    {
        
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
   
      

        $email = $request->input('email');
       
        $user = testuser::where('email', $email)
            ->first();

          
        if ($user !== null && Hash::check($request->input('password'), $user->password))
        {
            return redirect(route('index'));
        }
        else
        {

            return redirect("signin")->with(
                'error',
                'Wrong input'
            );;

        }
  
        
    }
}

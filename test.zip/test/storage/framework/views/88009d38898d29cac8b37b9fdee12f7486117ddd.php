

<!DOCTYPE html>
<html>
    <head>
        <title>Sign Up</title>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('csss.css')); ?>">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"  crossorigin="anonymous">
        <script src="https://kit.fontawesome.com/51f81a3552.js" crossorigin="anonymous"></script>
        <style>
            
        </style>
    </head>
    <body>
        <div class="row">
            <div class="col-md-6 " style="">
                <img src="img/1.png" style="float:left;width:100%;height:100%;object-fit:cover; background-color: black; filter: brightness(0.25);"/>
                <h1 class="move">Sign up to Studiomart</h1>
                <p class="dont">Already have an account? You can</p>
                <p class="signuphere">Sign in here</p>
            </div>
            <div class="login col-md-6">
            <div class="">
                

                    <div class="login-wrap p-4 p-md-5">

                        <h3 class="textt">Sign Up</h3>
                        <p class="signutext">Signup to get started</p>
                        
                        <form  class="signin-form" id="login" action="<?php echo e(route('signup')); ?>" method="POST" accept-charset="UTF-8"  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>


                            <div class="form-group mb-3">
                                <label class="label" for="firstname">First Nmae</label>
                                <input type="text" class="form-control" placeholder="Enter your first name" required="" name="firstname">
                            </div>
                            <div class="form-group mb-3">
                                <label class="label" for="lastname">Last Name</label>
                                <input type="text" class="form-control" placeholder="Enter your last name" required="" name="lastname">
                            </div>
                            <div class="form-group mb-3">
                                <label class="label" for="name">Email Address</label>
                                <input type="text" class="form-control" placeholder="Enter your email" required="" name="email">
                            </div>
                            <div class="form-group mb-3">
                                <label class="label" for="password">Password</label>
                                <input type="password" class="form-control" placeholder="Enter your password" required="" name="password">

                            </div>

                            <div class="form-group mb-3">
                                <label class="label" for="password">Re-enter Password</label>
                                <input type="password" class="form-control" placeholder="Confirm your password" required="" name="password_confirmation">

                            </div>

                            
                            
                            <div class="form-group  mb-3">
                                <div class="text-left">
                                    <label class="checkbox-wrap checkbox-primary" >
                                    <input type="checkbox" checked="false">
                                    <span class="checkmark"></span>
                                I have read, understood and accept the Terms and Conditions
                                    </label>
                                </div>
                                <!-- <div class="w-50 text-md-right">
                                    <a href="#">Forgot Password</a>
                                </div> -->
                            </div>

                            <div class="form-group">
                                    <button type="submit" class="form-control btn btn-primary rounded submit px-3">Sign Up</button>
                            </div>
                        </form>
                    
                        </div>
                    </div>
              
            </div>
          
        </div>
      
    </body>
</html>
<?php /**PATH C:\Users\user\Desktop\Laravel Test\test\resources\views/signup.blade.php ENDPATH**/ ?>
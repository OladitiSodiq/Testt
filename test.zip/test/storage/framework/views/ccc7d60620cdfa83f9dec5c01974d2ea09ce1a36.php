
<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <link rel="stylesheet" type="text/css"    href="<?php echo e(asset('csss.css')); ?>">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"  crossorigin="anonymous">
        <script src="https://kit.fontawesome.com/51f81a3552.js" crossorigin="anonymous"></script>
        <style>
            
        </style>
    </head>
    <body>
        <div class="row">
            <div class="col-md-6 " style="">
                <img src="img/1.png" style="float:left;width:100%;height:100%;object-fit:cover; background-color: black; filter: brightness(0.25);"/>
                <h1 class="move">Sign in to Studiomart</h1>
                <p class="dont">Dont have an account? You can</p>
                <p class="signuphere">Sign up here</p>
            </div>
            <div class="col-md-6">


                    <div class="login">
                        <div class="">
                        
                                <div class="login-wrap p-4 p-md-5">
                                
                                    <h3 class="textt">Sign In</h3>
                                    <p class="logtext">Login to your account to cintinue</p>
                                    <form  class="signin-form" id="login" action="<?php echo e(route('login')); ?>" method="POST" accept-charset="UTF-8"  enctype="multipart/form-data">
                                    <?php if(Session::has('error')): ?>
                                        <div class="alert alert-danger">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <strong>Oops!</strong> <?php echo e(Session::get('error')); ?>

                                        </div>
                                    <?php endif; ?>
                                         <?php echo csrf_field(); ?>


                                        <div class="form-group mb-3">
                                            <label class="label" for="name">Email Address</label>
                                            <input type="text" class="form-control" placeholder="Enter your email" required="" name="email">
                                        </div>
                                        <div class="form-group mb-3">
                                            <label class="label" for="password">Password</label>
                                            <input type="password" class="form-control" placeholder="Enter your password" required="" name="password">

                                        </div>

                                        
                                        
                                        <div class="form-group d-md-flex">
                                            <div class="w-50 text-left">
                                                <label class="checkbox-wrap checkbox-primary mb-0">
                                                <input type="checkbox" checked="false">
                                                <span class="checkmark"></span>
                                                Remember Me
                                                </label>
                                            </div>
                                            <div class="w-80 text-md-right">
                                                <a href="#">Forgot Password</a>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="form-group">
                                                <button type="submit" class="form-control btn btn-primary rounded submit px-3">Sign In</button>
                                        </div>
                                    </form>
                                
                                    </div>
                                </div>
                        
                        </div>
                    </div>

             
          
        </div>
      
    </body>
</html>
<?php /**PATH C:\Users\user\Desktop\Laravel Test\test\resources\views/login.blade.php ENDPATH**/ ?>
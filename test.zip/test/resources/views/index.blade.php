
<!DOCTYPE html>
<html>
    <head>
        <title>Homepage</title>
        <link rel="stylesheet" type="text/css"  href="{{asset('csss.css')}}">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"  crossorigin="anonymous">
        <script src="https://kit.fontawesome.com/51f81a3552.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
        
        <style type='text/css'>

       
            
           
        </style>
            
            
    </head>
    
    <body>

           



            <div class="topnav">
                    <a lass="Home" href="#"><b>StudioMart</b></a></li> 
                <a lass="Home" href="#">Home</a></li> 
                <a class="Contact" href="#">Studio</a>
                <a class="About" href="#">About</a>
                <a class="FAQ" href="#">How it works</a>
                <a class="Register" href="#"><span style="color: teal;">Become a Vendor</span></a>
                <a class="Login" href="#">Login</a>
                <a class="btn  btn-primary" href="#">Sign up</a>

         
          

            </div>



            <section class="pd">
                <div class="breatcome_area">

                </div>
                <!-- <img src="./img/2.png" style="float:left;width:100%;height:100%;object-fit:cover; background-color: black; filter: brightness(0.25);"/>                  -->
                
                <p class="ownstudio">Do you own a Studio? Start earning </p>

                <h3 class="list">List your studio and start earning from bookings.</h3>

                <button type="button" class="mvbtn btn btn-primary ">Become a Vendor </button>
            </section>

           


            <div class="row pt-50 merginrl">

                <div class="title-text-center mb-50 pd-80">
                        <h1 >Start Earning in just 3 Steps</h1>
                </div>

                <div class="col-md-4">

                    <!-- <p class="ownstudio">Do you own a Studio? Start earning </p> -->
                    <h3>Add Studio </h3>

                    <p>
                            Discover Studios near you Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores.
                    </p>

                </div>

                <div class="col-md-4">

                        <h3>Get Booked </h3>

                        <p>
                                Discover Studios near you Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores.
                        </p>

                </div>


                <div class="col-md-4">

                        <h3>Recieve Payment </h3>

                        <p>
                                Discover Studios near you Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores.
                        </p>

                </div>



              

            </div>
            <button type="button" class="btn btn-primary btn-lg mvbtnss">Become a Vendor</button>
            <br>
            <br>
            <br>



            <div class="row pt-502 merginrl bdc">
                    <div class="col-md-5">
                        <img src="./img/cell-phone.png" height="100%"/>
                    </div>

                    <div class="col-md-7">

                        <h1 class="down"><b>Download the <br> Mobile App </b></h1>

                        <label class="stdmart">StudioMart is available on playstore</label>
                        <br>
                        <br>
                        <br>



                        <button type="button" class="btn btn-dark">
                             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-google-play" viewBox="0 0 16 16">
                            <path d="M14.222 9.374c1.037-.61 1.037-2.137 0-2.748L11.528 5.04 8.32 8l3.207 2.96 2.694-1.586Zm-3.595 2.116L7.583 8.68 1.03 14.73c.201 1.029 1.36 1.61 2.303 1.055l7.294-4.295ZM1 13.396V2.603L6.846 8 1 13.396ZM1.03 1.27l6.553 6.05 3.044-2.81L3.333.215C2.39-.341 1.231.24 1.03 1.27Z"/>
                          </svg>
                          <small>Download on <br></small> Google Play</button>

                    </div>

            </div>


            <div class="row pt-50 merginrl">

                    <div class="title-text-center mb-50 pd-80">
                            <h1 >Why StudioMart?</h1>
                    </div>


                <div class="col-md-6">
                    <ul class="ullist">
                        <li class="listyle">
                            Rent a Studio
                        </li>

                    </ul>

                    <p  class="ullist">
                        Nemo enim ipsam volupatem quia voluptas sit aspernatur aut odit enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut odit aut odit.
                    </p>


                    <ul class="ullist">
                            <li class="listyle">
                                Rent a Studio
                            </li>
    
                        </ul>
    
                        <p  class="ullist">
                            Nemo enim ipsam volupatem quia voluptas sit aspernatur aut odit enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut odit aut odit.
                        </p>

                </div>
                <div class="col-md-6">
                        <ul class="ullist">
                            <li class="listyle">
                                Rent a Studio
                            </li>
    
                        </ul>
    
                        <p  class="ullist">
                                Nemo enim ipsam volupatem quia voluptas sit aspernatur aut odit enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut odit aut odit.
                        </p>

                        <ul class="ullist">
                                <li class="listyle">
                                    Rent a Studio
                                </li>
        
                            </ul>
        
                            <p  class="ullist">
                                Nemo enim ipsam volupatem quia voluptas sit aspernatur aut odit enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut odit aut odit.
                            </p>

                </div>

            </div>

            <div class="row pt-50 merginrl">

                    <div class="title-text-center mb-50 pd-80">
                            <h1 >Frequently Asked Questions</h1>
                    </div>
            </div>



        <!-- <p class="" style="background-color: aqua">
            color, font and text properties are inherited.  Other properties, such as border, margin,
            and padding, are not inherited.
        </p> -->
    </body>

</html>